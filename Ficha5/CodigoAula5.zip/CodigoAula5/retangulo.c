
#include "retangulo.h"
#include <stdio.h>

// Escreve as coordenadas dos 4 cantos do retangulo recebido como parâmetro
void printRet(ret r){
}

// Inicializa os dados do retangulo referenciado pelo parâmetro recebido.
// O utilizador indica os valores
void initRet(ret* p){

}

// Devolve a area do retangulo recebido como parâmetro
int areaR(ret r){
    return 0;
}

// Verifica se o ponto a se encontra dentro do retangulo r
// Devolve 1 se suceder, ou 0, caso contrario
int dentroR(ret r, ponto2D a){
    return 0;
}

// Verifica se os 2 retangulos recebidos como parametro se intersetam.
// Devolve 1 se suceder, ou 0, caso contrario
int overlap(ret r1, ret r2){
    return 0;
}